from monte_carlo import monte1_solution
from scoring import score_answer
from full import full_solution

# Output:
# teams (N2, N3, N4) - number of teams with 2/3/4 persons
# pizzas [[I11, ..I1i], ... [In1, ... Ini]] - numerical ingredient list
def read_file(name):
    ingr_dict = {}
    with open(name) as f:
        P, N2, N3, N4 = [int(x) for x in next(f).split()]
        pizzas: list[list[int]] = []
        for i in range(P):
            pizza: list[int] = []
            data = next(f).split()
            ingr = data[1:]
            for i in ingr:
                if (i in ingr_dict.keys()):
                    pizza.append(ingr_dict[i])
                else:
                    pizza.append(len(ingr_dict))
                    ingr_dict[i] = len(ingr_dict)
            pizzas.append(pizza)
    #    print(ingr_dict)
#    print("Teams: N2: ", N2, " N3: ", N3, " N4: ", N4)
#    print("Pizzas: %s" % pizzas)
    return (N2, N3, N4), pizzas


def write_result(answer: list[list[int]], score, out_file):
#    print("Answer: %s" % answer)
    print(out_file, " solution score: %d" % score)
    with open(out_file, "w+") as f:
        f.write(str(len(answer)) + '\n')
        for delivery in answer:
            desc = str(delivery).replace('[', '').replace(']', '').replace(',', '')
            desc = str(len(delivery)) + ' ' + desc + '\n'
            f.write(desc)


def dummy_solution(teams, pizzas):
    (N2, N3, N4) = teams
    n_pizzas = [[i, pizzas[i]] for i in range(len(pizzas))]
    answer = []
    while(((N2 > 0) and (len(n_pizzas) >= 2)) or
          ((N3 > 0) and (len(n_pizzas) >= 3)) or
          ((N4 > 0) and (len(n_pizzas) >= 4))):
        team_delivery = []
        if len(n_pizzas) >= 4:
            team_delivery.append(n_pizzas[0][0])
            team_delivery.append(n_pizzas[1][0])
            team_delivery.append(n_pizzas[2][0])
            team_delivery.append(n_pizzas[3][0])
            del n_pizzas[0:4]
            N4 -= 1
        elif len(n_pizzas) >= 3:
            team_delivery.append(n_pizzas[0][0])
            team_delivery.append(n_pizzas[1][0])
            team_delivery.append(n_pizzas[2][0])
            del n_pizzas[0:3]
            N3 -= 1
        else:
            team_delivery.append(n_pizzas[0][0])
            team_delivery.append(n_pizzas[1][0])
            del n_pizzas[0:2]
            N2 -= 1
        answer.append(team_delivery)
    return answer

def solution(in_file, out_file):
    teams, pizzas = read_file(in_file)
#    answer = dummy_solution(teams, pizzas)
#    answer = monte1_solution(teams, pizzas)
    answer = full_solution(teams, pizzas)
    write_result(answer, score_answer(answer, pizzas), out_file)

if __name__ == '__main__':
    solution('a_example',                     'a_result_full')
#    solution('b_little_bit_of_everything.in', 'b_result_full')
#    solution('c_many_ingredients.in',         'c_result_full')
#    solution('d_many_pizzas.in',              'd_result_full')
#    solution('e_many_teams.in',               'e_result_full')
